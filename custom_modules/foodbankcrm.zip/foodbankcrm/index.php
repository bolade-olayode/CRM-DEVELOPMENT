<?php
/**
 * FOODBANK CRM — PUBLIC LANDING PAGE
 * Auto-redirects logged-in users to their dashboard.
 */

if (!defined("NOLOGIN"))    define("NOLOGIN",    1);
if (!defined("NOCSRFCHECK")) define("NOCSRFCHECK", 1);
if (!defined("NOIPCHECK"))  define("NOIPCHECK",  1);

require_once dirname(__DIR__, 2) . '/main.inc.php';
require_once DOL_DOCUMENT_ROOT . '/custom/foodbankcrm/class/permissions.class.php';

// Auto-redirect logged-in users
if (!empty($user->id)) {
    if ($user->admin || FoodbankPermissions::isAdmin($user)) {
        header('Location: core/pages/dashboard_admin.php'); exit;
    } elseif (FoodbankPermissions::isVendor($user, $db)) {
        header('Location: core/pages/dashboard_vendor.php'); exit;
    } elseif (FoodbankPermissions::isBeneficiary($user, $db)) {
        header('Location: core/pages/dashboard_beneficiary.php'); exit;
    }
    header('Location: '.DOL_URL_ROOT.'/index.php'); exit;
}

$login_url      = DOL_URL_ROOT . '/index.php?backtopage=' . urlencode(DOL_URL_ROOT . '/custom/foodbankcrm/index.php');
$base           = DOL_URL_ROOT . '/custom/foodbankcrm';
$logo_colored   = $base . '/img/logo.png';
$logo_white     = $base . '/img/logo-white.png';
$favicon        = $base . '/img/favicon.png';
$register_url   = 'core/pages/register.php';
$vendor_url     = 'core/pages/register_vendor.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foodbank CRM | Smart Food Distribution Platform</title>
    <meta name="description" content="Connecting communities through efficient food distribution. Subscribe, browse packages, and get food delivered — all in one platform.">
    <link rel="icon" type="image/png" href="<?php echo $favicon; ?>">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }

        :root {
            --green:      #0d9488;
            --green-dark: #0f766e;
            --green-faint:#f0fdfa;
            --orange:     #ea580c;
            --text:       #0f172a;
            --muted:      #64748b;
            --border:     #e2e8f0;
            --card:       #f8fafc;
        }

        body { font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; color: var(--text); background: #fff; }

        /* ── NAV ────────────────────────────────────────────────── */
        nav {
            position: fixed; top: 0; left: 0; right: 0; z-index: 200;
            height: 64px;
            display: flex; align-items: center; justify-content: space-between;
            padding: 0 5%;
            background: rgba(255,255,255,0.96);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid var(--border);
            transition: box-shadow .2s;
        }
        nav.scrolled { box-shadow: 0 2px 16px rgba(0,0,0,0.07); }
        .nav-logo img { height: 34px; display: block; }
        .nav-links { display: flex; align-items: center; gap: 32px; }
        .nav-links a {
            font-size: 14px; font-weight: 500; color: var(--muted);
            text-decoration: none; transition: color .15s;
        }
        .nav-links a:hover { color: var(--green); }
        .nav-cta { display: flex; gap: 10px; }
        .btn-nav-ghost {
            padding: 8px 18px; border-radius: 8px;
            border: 1.5px solid var(--border); background: transparent;
            font-size: 14px; font-weight: 600; color: var(--text);
            text-decoration: none; transition: all .15s;
        }
        .btn-nav-ghost:hover { border-color: var(--green); color: var(--green); }
        .btn-nav-solid {
            padding: 8px 18px; border-radius: 8px;
            background: var(--green); color: #fff;
            font-size: 14px; font-weight: 600;
            text-decoration: none; transition: background .15s;
        }
        .btn-nav-solid:hover { background: var(--green-dark); }
        .hamburger { display: none; flex-direction: column; gap: 5px; cursor: pointer; padding: 6px; }
        .hamburger span { display: block; width: 22px; height: 2px; background: var(--text); border-radius: 2px; transition: all .2s; }
        .mobile-menu {
            display: none; position: fixed; top: 64px; left: 0; right: 0; z-index: 199;
            background: #fff; border-bottom: 1px solid var(--border);
            padding: 20px 5%; flex-direction: column; gap: 16px;
        }
        .mobile-menu.open { display: flex; }
        .mobile-menu a { font-size: 15px; font-weight: 500; color: var(--text); text-decoration: none; }
        .mobile-menu .mob-cta { display: flex; flex-direction: column; gap: 10px; margin-top: 8px; }
        .mob-cta a { text-align: center; }

        /* ── HERO ───────────────────────────────────────────────── */
        #home {
            min-height: 100vh;
            display: flex; align-items: center;
            background: linear-gradient(155deg, #f0fdfa 0%, #e0f7fa 40%, #fef9ee 100%);
            padding: 100px 5% 80px;
        }
        .hero-inner {
            max-width: 1100px; margin: 0 auto;
            display: grid; grid-template-columns: 1fr 1fr; gap: 60px; align-items: center;
        }
        .hero-left h1 {
            font-size: clamp(34px, 4.5vw, 56px);
            font-weight: 900; line-height: 1.1;
            letter-spacing: -1.5px; margin-bottom: 20px;
        }
        .hero-left h1 span { color: var(--green); }
        .hero-left p {
            font-size: 18px; color: var(--muted); line-height: 1.75;
            margin-bottom: 36px; max-width: 480px;
        }
        .hero-btns { display: flex; gap: 14px; flex-wrap: wrap; }
        .btn-hero-primary {
            padding: 15px 34px; border-radius: 11px;
            background: var(--green); color: #fff;
            font-size: 16px; font-weight: 700; text-decoration: none;
            transition: background .2s, transform .2s;
        }
        .btn-hero-primary:hover { background: var(--green-dark); transform: translateY(-2px); }
        .btn-hero-outline {
            padding: 15px 34px; border-radius: 11px;
            border: 2px solid var(--green); color: var(--green);
            font-size: 16px; font-weight: 700; text-decoration: none;
            background: transparent; transition: all .2s;
        }
        .btn-hero-outline:hover { background: var(--green-faint); transform: translateY(-2px); }
        .hero-right {
            display: flex; justify-content: center;
        }
        .hero-phone-mock {
            width: 260px; height: 480px;
            background: #1e293b;
            border-radius: 40px;
            box-shadow: 0 40px 80px rgba(0,0,0,0.22), 0 0 0 8px #0f172a;
            position: relative; overflow: hidden;
            display: flex; flex-direction: column;
        }
        .mock-notch {
            position: absolute; top: 12px; left: 50%; transform: translateX(-50%);
            width: 80px; height: 20px; background: #0f172a;
            border-radius: 10px; z-index: 10;
        }
        .mock-screen {
            flex: 1; background: var(--green-faint);
            display: flex; flex-direction: column; align-items: center;
            justify-content: center; padding: 24px 16px; gap: 14px;
            padding-top: 48px;
        }
        .mock-screen img { width: 110px; }
        .mock-screen .mock-title { font-size: 14px; font-weight: 800; color: var(--text); }
        .mock-screen .mock-card {
            width: 100%; background: #fff;
            border-radius: 12px; padding: 12px 14px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        .mock-card-label { font-size: 9px; color: var(--muted); font-weight: 600; text-transform: uppercase; letter-spacing: .5px; }
        .mock-card-val { font-size: 18px; font-weight: 800; color: var(--green); }
        .mock-bar { width: 100%; height: 6px; background: #e2e8f0; border-radius: 3px; overflow: hidden; }
        .mock-bar-fill { height: 100%; width: 65%; background: var(--green); border-radius: 3px; }
        .mock-tag { font-size: 9px; color: var(--muted); text-align: right; }

        /* Stats strip */
        .stats-strip {
            background: var(--green);
            padding: 28px 5%;
            display: flex; justify-content: center; gap: 64px; flex-wrap: wrap;
        }
        .stat-item { text-align: center; color: #fff; }
        .stat-num { font-size: 32px; font-weight: 900; letter-spacing: -1px; }
        .stat-lbl { font-size: 13px; opacity: .8; margin-top: 2px; }

        /* ── SECTION SHARED ──────────────────────────────────────── */
        section { padding: 96px 5%; }
        .section-inner { max-width: 1100px; margin: 0 auto; }
        .section-tag {
            display: inline-block; padding: 5px 14px; border-radius: 20px;
            background: #ccfbf1; color: var(--green-dark);
            font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px;
            margin-bottom: 16px;
        }
        .section-tag.orange { background: #ffedd5; color: var(--orange); }
        h2.section-title {
            font-size: clamp(26px, 3.5vw, 38px); font-weight: 900;
            letter-spacing: -1px; line-height: 1.2; margin-bottom: 16px;
        }
        p.section-sub { font-size: 17px; color: var(--muted); line-height: 1.7; max-width: 560px; }
        .center { text-align: center; }
        .center p.section-sub { margin: 0 auto 52px; }

        /* ── FEATURES ────────────────────────────────────────────── */
        #features { background: #fff; }
        .feature-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 24px; margin-top: 52px;
        }
        .feature-card {
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 16px; padding: 32px 24px;
            transition: box-shadow .2s, transform .2s;
        }
        .feature-card:hover { box-shadow: 0 8px 32px rgba(0,0,0,0.07); transform: translateY(-3px); }
        .f-icon {
            width: 48px; height: 48px; border-radius: 12px;
            background: #ccfbf1; display: flex; align-items: center; justify-content: center;
            font-size: 22px; margin-bottom: 18px;
        }
        .feature-card h3 { font-size: 17px; font-weight: 700; margin-bottom: 10px; }
        .feature-card p { font-size: 14px; color: var(--muted); line-height: 1.65; }

        /* ── HOW IT WORKS ────────────────────────────────────────── */
        #how { background: linear-gradient(160deg, #f0fdfa 0%, #f8fafc 100%); }
        .steps { display: grid; grid-template-columns: repeat(3, 1fr); gap: 32px; margin-top: 52px; }
        .step { text-align: center; }
        .step-num {
            width: 52px; height: 52px; border-radius: 50%;
            background: var(--green); color: #fff;
            font-size: 20px; font-weight: 900;
            display: flex; align-items: center; justify-content: center;
            margin: 0 auto 18px;
        }
        .step h3 { font-size: 17px; font-weight: 700; margin-bottom: 10px; }
        .step p { font-size: 14px; color: var(--muted); line-height: 1.65; }
        .step-arrow {
            display: none; /* shown via CSS for larger screens */
        }

        /* ── BENEFICIARY SECTION ─────────────────────────────────── */
        #beneficiaries { background: #fff; }
        .split { display: grid; grid-template-columns: 1fr 1fr; gap: 72px; align-items: center; }
        .split-reverse { direction: rtl; }
        .split-reverse > * { direction: ltr; }
        .benefit-list { list-style: none; display: flex; flex-direction: column; gap: 18px; margin: 28px 0 36px; }
        .benefit-list li {
            display: flex; align-items: flex-start; gap: 14px;
            font-size: 15px; color: var(--muted); line-height: 1.55;
        }
        .benefit-list .chk {
            width: 24px; height: 24px; min-width: 24px;
            border-radius: 50%; background: #ccfbf1;
            display: flex; align-items: center; justify-content: center;
            font-size: 12px; color: var(--green); margin-top: 1px;
        }
        .visual-card {
            background: linear-gradient(145deg, var(--green), var(--green-dark));
            border-radius: 20px; padding: 32px; color: #fff;
        }
        .visual-card h3 { font-size: 20px; font-weight: 800; margin-bottom: 24px; }
        .tier-row {
            background: rgba(255,255,255,0.15); border-radius: 10px;
            padding: 12px 16px; margin-bottom: 12px;
            display: flex; justify-content: space-between; align-items: center;
        }
        .tier-row:last-child { margin-bottom: 0; }
        .tier-name { font-size: 14px; font-weight: 700; }
        .tier-badge {
            font-size: 11px; font-weight: 700; padding: 3px 10px;
            border-radius: 20px; background: rgba(255,255,255,0.25);
        }

        /* ── VENDOR SECTION ──────────────────────────────────────── */
        #vendors { background: #fffbf7; }
        .vendor-card {
            background: linear-gradient(145deg, #ea580c, #c2410c);
            border-radius: 20px; padding: 32px; color: #fff;
        }
        .vendor-stat { text-align: center; padding: 20px; }
        .vendor-stat-num { font-size: 36px; font-weight: 900; }
        .vendor-stat-lbl { font-size: 12px; opacity: .8; }
        .vendor-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 2px; border-radius: 12px; overflow: hidden; }
        .vendor-stat:nth-child(odd) { background: rgba(255,255,255,0.12); }
        .vendor-stat:nth-child(even) { background: rgba(0,0,0,0.08); }
        .btn-orange {
            display: inline-flex; align-items: center; gap: 8px;
            padding: 15px 34px; border-radius: 11px;
            background: var(--orange); color: #fff;
            font-size: 16px; font-weight: 700; text-decoration: none;
            transition: background .2s, transform .2s;
        }
        .btn-orange:hover { background: #c2410c; transform: translateY(-2px); }

        /* ── APP SECTION ─────────────────────────────────────────── */
        #app {
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
            color: #fff;
        }
        #app .section-inner {
            display: grid; grid-template-columns: 1fr 1fr; gap: 64px; align-items: center;
        }
        #app h2.section-title { color: #fff; }
        #app p.section-sub { color: #94a3b8; max-width: none; }
        .app-features { display: flex; flex-direction: column; gap: 16px; margin: 28px 0 36px; }
        .app-feat {
            display: flex; align-items: center; gap: 14px;
            font-size: 15px; color: #94a3b8;
        }
        .app-feat-icon {
            width: 38px; height: 38px; min-width: 38px; border-radius: 10px;
            background: rgba(255,255,255,0.08);
            display: flex; align-items: center; justify-content: center; font-size: 18px;
        }
        .download-badges { display: flex; gap: 14px; flex-wrap: wrap; }
        .badge-btn {
            display: inline-flex; align-items: center; gap: 10px;
            padding: 13px 22px; border-radius: 11px;
            background: rgba(255,255,255,0.1);
            border: 1.5px solid rgba(255,255,255,0.2);
            color: #fff; text-decoration: none;
            transition: background .2s;
        }
        .badge-btn:hover { background: rgba(255,255,255,0.18); }
        .badge-btn .badge-icon { font-size: 24px; }
        .badge-btn .badge-text { display: flex; flex-direction: column; }
        .badge-btn .badge-sub { font-size: 10px; opacity: .7; }
        .badge-btn .badge-title { font-size: 15px; font-weight: 700; }
        .app-visual {
            display: flex; justify-content: center; gap: -20px;
        }
        .phone-small {
            width: 140px; height: 260px;
            background: #0f172a; border-radius: 24px;
            box-shadow: 0 20px 50px rgba(0,0,0,0.4), 0 0 0 5px #1e293b;
            overflow: hidden; position: relative;
        }
        .phone-small .ps-screen {
            height: 100%;
            background: var(--green-faint);
            display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 16px;
        }
        .phone-small .ps-screen img { width: 70px; }
        .phone-big {
            width: 180px; height: 320px;
            background: #0f172a; border-radius: 30px;
            box-shadow: 0 24px 64px rgba(0,0,0,0.5), 0 0 0 6px #1e293b;
            overflow: hidden; position: relative;
            transform: translateY(-24px) translateX(-20px);
        }
        .phone-big .pb-screen {
            height: 100%;
            background: #fff;
            display: flex; flex-direction: column; padding-top: 28px;
        }
        .pb-topbar {
            background: var(--green); padding: 12px 16px;
            display: flex; align-items: center; gap: 8px;
        }
        .pb-topbar img { height: 20px; filter: brightness(0) invert(1); }
        .pb-body { padding: 14px 12px; display: flex; flex-direction: column; gap: 8px; }
        .pb-pkg {
            background: var(--card); border-radius: 8px; padding: 10px 12px;
            display: flex; gap: 8px; align-items: center;
        }
        .pb-pkg-color { width: 32px; height: 32px; border-radius: 8px; background: #ccfbf1; }
        .pb-pkg-info .pkg-name { font-size: 9px; font-weight: 700; }
        .pb-pkg-info .pkg-price { font-size: 9px; color: var(--green); font-weight: 700; }

        /* ── FOOTER ──────────────────────────────────────────────── */
        footer {
            background: #0f172a; color: #fff;
            padding: 60px 5% 32px;
        }
        .footer-top {
            display: grid; grid-template-columns: 2fr 1fr 1fr 1fr;
            gap: 48px; margin-bottom: 48px;
        }
        .footer-brand img { height: 32px; margin-bottom: 16px; filter: brightness(0) invert(1); }
        .footer-brand p { font-size: 14px; color: #94a3b8; line-height: 1.65; max-width: 260px; }
        .footer-col h4 { font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; color: #64748b; margin-bottom: 16px; }
        .footer-col a { display: block; font-size: 14px; color: #94a3b8; text-decoration: none; margin-bottom: 10px; transition: color .15s; }
        .footer-col a:hover { color: #fff; }
        .footer-bottom {
            border-top: 1px solid #1e293b;
            padding-top: 24px;
            display: flex; justify-content: space-between; align-items: center;
            font-size: 13px; color: #475569;
        }

        /* ── RESPONSIVE ──────────────────────────────────────────── */
        @media (max-width: 900px) {
            .hero-inner { grid-template-columns: 1fr; }
            .hero-right { display: none; }
            .feature-grid { grid-template-columns: 1fr 1fr; }
            .steps { grid-template-columns: 1fr; max-width: 420px; margin: 52px auto 0; }
            .split, .split-reverse { grid-template-columns: 1fr; direction: ltr; }
            #app .section-inner { grid-template-columns: 1fr; }
            .app-visual { display: none; }
            .footer-top { grid-template-columns: 1fr 1fr; }
            .nav-links { display: none; }
            .hamburger { display: flex; }
        }
        @media (max-width: 600px) {
            section { padding: 72px 6%; }
            #home { padding: 90px 6% 60px; }
            .feature-grid { grid-template-columns: 1fr; }
            .stats-strip { gap: 36px; }
            .footer-top { grid-template-columns: 1fr; gap: 32px; }
            .footer-bottom { flex-direction: column; gap: 8px; text-align: center; }
        }
    </style>
</head>
<body>

<!-- ── NAV ─────────────────────────────────────────────────────────── -->
<nav id="topnav">
    <a href="#home" class="nav-logo"><img src="<?php echo $logo_colored; ?>" alt="Foodbank CRM"></a>
    <div class="nav-links">
        <a href="#features">Features</a>
        <a href="#how">How It Works</a>
        <a href="#beneficiaries">For Beneficiaries</a>
        <a href="#vendors">For Vendors</a>
        <a href="#app">Mobile App</a>
    </div>
    <div class="nav-cta">
        <a href="<?php echo $login_url; ?>" class="btn-nav-ghost">Sign In</a>
        <a href="<?php echo $register_url; ?>" class="btn-nav-solid">Get Started</a>
    </div>
    <div class="hamburger" id="hamburger">
        <span></span><span></span><span></span>
    </div>
</nav>

<!-- Mobile menu -->
<div class="mobile-menu" id="mobile-menu">
    <a href="#features" class="mob-link">Features</a>
    <a href="#how" class="mob-link">How It Works</a>
    <a href="#beneficiaries" class="mob-link">For Beneficiaries</a>
    <a href="#vendors" class="mob-link">For Vendors</a>
    <a href="#app" class="mob-link">Mobile App</a>
    <div class="mob-cta">
        <a href="<?php echo $login_url; ?>" class="btn-nav-ghost">Sign In</a>
        <a href="<?php echo $register_url; ?>" class="btn-nav-solid">Get Started Free</a>
    </div>
</div>

<!-- ── HERO ─────────────────────────────────────────────────────────── -->
<section id="home">
    <div class="hero-inner">
        <div class="hero-left">
            <h1>Smart Food<br>Distribution<br><span>For Every Community</span></h1>
            <p>Subscribe to a plan, browse food packages, place orders, and track every delivery — all from one platform built for food banks.</p>
            <div class="hero-btns">
                <a href="<?php echo $register_url; ?>" class="btn-hero-primary">Create Free Account</a>
                <a href="<?php echo $login_url; ?>" class="btn-hero-outline">Sign In</a>
            </div>
        </div>
        <div class="hero-right">
            <div class="hero-phone-mock">
                <div class="mock-notch"></div>
                <div class="mock-screen">
                    <img src="<?php echo $logo_colored; ?>" alt="Foodbank CRM">
                    <div class="mock-title">My Dashboard</div>
                    <div class="mock-card">
                        <div class="mock-card-label">Orders This Month</div>
                        <div class="mock-card-val">4 / 6</div>
                        <div class="mock-bar"><div class="mock-bar-fill"></div></div>
                        <div class="mock-tag">2 orders remaining</div>
                    </div>
                    <div class="mock-card">
                        <div class="mock-card-label">Active Subscription</div>
                        <div class="mock-card-val" style="font-size:13px;color:#0f172a;font-weight:700">Premium Plan</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ── STATS ─────────────────────────────────────────────────────────── -->
<div class="stats-strip">
    <div class="stat-item"><div class="stat-num">1000+</div><div class="stat-lbl">Beneficiaries Served</div></div>
    <div class="stat-item"><div class="stat-num">50+</div><div class="stat-lbl">Vendor Partners</div></div>
    <div class="stat-item"><div class="stat-num">5,000+</div><div class="stat-lbl">Orders Fulfilled</div></div>
    <div class="stat-item"><div class="stat-num">100%</div><div class="stat-lbl">Secure Payments</div></div>
</div>

<!-- ── FEATURES ──────────────────────────────────────────────────────── -->
<section id="features">
    <div class="section-inner">
        <div class="center">
            <span class="section-tag">Platform Features</span>
            <h2 class="section-title">Everything in one place</h2>
            <p class="section-sub">A complete end-to-end system for food bank management — from registration to delivery.</p>
        </div>
        <div class="feature-grid">
            <div class="feature-card">
                <div class="f-icon">📦</div>
                <h3>Package Catalogue</h3>
                <p>Browse curated food packages from verified vendors, with photos, descriptions, and tier-based availability.</p>
            </div>
            <div class="feature-card">
                <div class="f-icon">🛒</div>
                <h3>Cart & Checkout</h3>
                <p>Add packages to cart, select delivery details, and pay securely via Paystack — in seconds.</p>
            </div>
            <div class="feature-card">
                <div class="f-icon">📍</div>
                <h3>Live Order Tracking</h3>
                <p>Follow your order from Pending → Prepared → Bundled → In Transit → Delivered in real time.</p>
            </div>
            <div class="feature-card">
                <div class="f-icon">💳</div>
                <h3>Subscription Plans</h3>
                <p>Choose a plan that fits your needs — from browse-only access to unlimited monthly ordering.</p>
            </div>
            <div class="feature-card">
                <div class="f-icon">🤝</div>
                <h3>Vendor Network</h3>
                <p>Food vendors list products, receive and manage assigned orders, and track earnings — all from one dashboard.</p>
            </div>
            <div class="feature-card">
                <div class="f-icon">📊</div>
                <h3>Admin Control Room</h3>
                <p>Full oversight: registrations, payments, order pipeline, donations, and subscription management.</p>
            </div>
        </div>
    </div>
</section>

<!-- ── HOW IT WORKS ───────────────────────────────────────────────────── -->
<section id="how">
    <div class="section-inner">
        <div class="center">
            <span class="section-tag">How It Works</span>
            <h2 class="section-title">Get started in three steps</h2>
            <p class="section-sub">From sign-up to receiving your first food package — it's quick and easy.</p>
        </div>
        <div class="steps">
            <div class="step">
                <div class="step-num">1</div>
                <h3>Register & Subscribe</h3>
                <p>Create your account and choose a subscription plan that fits your needs. Subscriptions are paid securely via Paystack.</p>
            </div>
            <div class="step">
                <div class="step-num">2</div>
                <h3>Browse & Order</h3>
                <p>Explore available food packages, add to cart, confirm your delivery address, and complete your payment.</p>
            </div>
            <div class="step">
                <div class="step-num">3</div>
                <h3>Track & Receive</h3>
                <p>Follow your order status live — from preparation through bundling and transit, right to your door.</p>
            </div>
        </div>
    </div>
</section>

<!-- ── FOR BENEFICIARIES ──────────────────────────────────────────────── -->
<section id="beneficiaries">
    <div class="section-inner">
        <div class="split">
            <div class="split-text">
                <span class="section-tag">For Beneficiaries</span>
                <h2 class="section-title">Food security,<br>at your fingertips</h2>
                <ul class="benefit-list">
                    <li><div class="chk">✓</div><span>Browse food packages and place orders from the app or web browser</span></li>
                    <li><div class="chk">✓</div><span>Flexible subscription tiers — choose what fits your household</span></li>
                    <li><div class="chk">✓</div><span>See your monthly order usage and remaining allowance at a glance</span></li>
                    <li><div class="chk">✓</div><span>Get real-time status updates from order placement to delivery</span></li>
                    <li><div class="chk">✓</div><span>Manage your profile, address, and subscription in one place</span></li>
                </ul>
                <a href="<?php echo $register_url; ?>" class="btn-hero-primary">Register as Beneficiary</a>
            </div>
            <div class="split-visual">
                <div class="visual-card">
                    <h3>Subscription Tiers</h3>
                    <div class="tier-row"><span class="tier-name">Guest</span><span class="tier-badge">Browse Only</span></div>
                    <div class="tier-row"><span class="tier-name">Basic</span><span class="tier-badge">4 orders / month</span></div>
                    <div class="tier-row"><span class="tier-name">Standard</span><span class="tier-badge">8 orders / month</span></div>
                    <div class="tier-row"><span class="tier-name">Premium</span><span class="tier-badge">Unlimited</span></div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ── FOR VENDORS ────────────────────────────────────────────────────── -->
<section id="vendors">
    <div class="section-inner">
        <div class="split split-reverse">
            <div class="split-text">
                <span class="section-tag orange">For Vendors</span>
                <h2 class="section-title">Grow your reach<br>within the network</h2>
                <ul class="benefit-list">
                    <li><div class="chk" style="background:#ffedd5;color:#ea580c">✓</div><span>List your food products with images and pricing</span></li>
                    <li><div class="chk" style="background:#ffedd5;color:#ea580c">✓</div><span>Receive and manage orders assigned to your store</span></li>
                    <li><div class="chk" style="background:#ffedd5;color:#ea580c">✓</div><span>Update order status and track your fulfilment pipeline</span></li>
                    <li><div class="chk" style="background:#ffedd5;color:#ea580c">✓</div><span>View your earnings and supply history with detailed reports</span></li>
                    <li><div class="chk" style="background:#ffedd5;color:#ea580c">✓</div><span>Contact support directly from the vendor dashboard</span></li>
                </ul>
                <a href="<?php echo $vendor_url; ?>" class="btn-orange">Join as Vendor Partner</a>
            </div>
            <div class="split-visual">
                <div class="vendor-card">
                    <h3 style="margin-bottom:20px;font-size:18px;font-weight:800">Vendor Dashboard</h3>
                    <div class="vendor-grid">
                        <div class="vendor-stat"><div class="vendor-stat-num">24</div><div class="vendor-stat-lbl">Active Orders</div></div>
                        <div class="vendor-stat"><div class="vendor-stat-num">₦ 48k</div><div class="vendor-stat-lbl">This Month</div></div>
                        <div class="vendor-stat"><div class="vendor-stat-num">12</div><div class="vendor-stat-lbl">Products Listed</div></div>
                        <div class="vendor-stat"><div class="vendor-stat-num">98%</div><div class="vendor-stat-lbl">Fulfilment Rate</div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ── APP DOWNLOAD ───────────────────────────────────────────────────── -->
<section id="app">
    <div class="section-inner">
        <div>
            <span class="section-tag" style="background:rgba(255,255,255,.1);color:#94a3b8">Mobile App</span>
            <h2 class="section-title" style="color:#fff">Your food bank,<br>in your pocket</h2>
            <p class="section-sub">The Foodbank CRM app gives beneficiaries and vendors full access on the go — from ordering to delivery tracking.</p>
            <div class="app-features">
                <div class="app-feat"><div class="app-feat-icon">📱</div>Available on Android</div>
                <div class="app-feat"><div class="app-feat-icon">🔔</div>Push notifications for order updates</div>
                <div class="app-feat"><div class="app-feat-icon">🔒</div>Secure login with JWT authentication</div>
                <div class="app-feat"><div class="app-feat-icon">⚡</div>Fast, offline-capable with instant load</div>
            </div>
            <div class="download-badges">
                <a href="#" class="badge-btn">
                    <span class="badge-icon">▶</span>
                    <span class="badge-text">
                        <span class="badge-sub">Get it on</span>
                        <span class="badge-title">Google Play</span>
                    </span>
                </a>
                <a href="#" class="badge-btn">
                    <span class="badge-icon">⬇</span>
                    <span class="badge-text">
                        <span class="badge-sub">Direct Download</span>
                        <span class="badge-title">APK File</span>
                    </span>
                </a>
            </div>
        </div>
        <div class="app-visual">
            <div class="phone-small">
                <div class="ps-screen">
                    <img src="<?php echo $logo_colored; ?>" alt="">
                </div>
            </div>
            <div class="phone-big">
                <div class="pb-screen">
                    <div class="pb-topbar">
                        <img src="<?php echo $logo_colored; ?>" alt="Foodbank CRM">
                    </div>
                    <div class="pb-body">
                        <div class="pb-pkg"><div class="pb-pkg-color"></div><div class="pb-pkg-info"><div class="pkg-name">Fresh Produce Box</div><div class="pkg-price">₦ 2,500</div></div></div>
                        <div class="pb-pkg"><div class="pb-pkg-color" style="background:#fde68a"></div><div class="pb-pkg-info"><div class="pkg-name">Dry Goods Bundle</div><div class="pkg-price">₦ 1,800</div></div></div>
                        <div class="pb-pkg"><div class="pb-pkg-color" style="background:#fed7aa"></div><div class="pb-pkg-info"><div class="pkg-name">Protein Package</div><div class="pkg-price">₦ 3,200</div></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ── FOOTER ─────────────────────────────────────────────────────────── -->
<footer>
    <div class="footer-top">
        <div class="footer-brand">
            <img src="<?php echo $logo_colored; ?>" alt="Foodbank CRM">
            <p>Connecting communities through efficient food distribution and supply management.</p>
        </div>
        <div class="footer-col">
            <h4>Platform</h4>
            <a href="#features">Features</a>
            <a href="#how">How It Works</a>
            <a href="#app">Mobile App</a>
        </div>
        <div class="footer-col">
            <h4>Get Started</h4>
            <a href="<?php echo $register_url; ?>">Register as Beneficiary</a>
            <a href="<?php echo $vendor_url; ?>">Become a Vendor</a>
            <a href="<?php echo $login_url; ?>">Sign In</a>
        </div>
        <div class="footer-col">
            <h4>Contact</h4>
            <a href="mailto:support@xdigitalfoodbank.com">support@xdigitalfoodbank.com</a>
            <a href="https://xdigitalfoodbank.com">xdigitalfoodbank.com</a>
        </div>
    </div>
    <div class="footer-bottom">
        <span>&copy; <?php echo date('Y'); ?> Foodbank CRM. All rights reserved.</span>
        <span>xdigitalfoodbank.com</span>
    </div>
</footer>

<script>
// Sticky nav shadow
window.addEventListener('scroll', function () {
    document.getElementById('topnav').classList.toggle('scrolled', window.scrollY > 10);
});

// Hamburger menu
document.getElementById('hamburger').addEventListener('click', function () {
    document.getElementById('mobile-menu').classList.toggle('open');
});

// Close mobile menu on link click
document.querySelectorAll('.mob-link').forEach(function (a) {
    a.addEventListener('click', function () {
        document.getElementById('mobile-menu').classList.remove('open');
    });
});
</script>

</body>
</html>
